$(document).ready(function(){
    $("button").click(function(){
        $("recap").toggle();
    });
});
